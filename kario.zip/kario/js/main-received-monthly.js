
function starttime() {
  document.getElementById("starttimebtn").click();
}
function endtime() {
  document.getElementById("endtimebtn").click();
}
function leavetime() {
  document.getElementById("leavetimebtn").click();
}
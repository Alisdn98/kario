
function starttime() {
  document.getElementById("starttimebtn").click();
}

function endtime() {
  document.getElementById("endtimebtn").click();
}

function leavetime() {
  document.getElementById("leavetimebtn").click();
}

function writedate() {
  var x = document.getElementById('azdate').value;
  var y = document.getElementById('tadate').value;
  document.getElementById('innerp').innerHTML ="از تاریخ"+ " " + y + "<br>" + "تا تاریخ" + " " + x;
  document.getElementById('report-time').style.backgroundColor= "rgba(254,192,70,0.40)";
  document.getElementById('starttimebtn').style.backgroundColor= "rgba(254,192,70,0.40)";
  document.getElementById('report-month').style.backgroundColor= "white";
  document.getElementById('endtimebtn').style.backgroundColor= "white";
  document.getElementById('sub-for-time').style.display="inline-block";
  document.getElementById('sub-for-monthly').style.display="none";
}

function writemonth() {
  var x = document.getElementById('year-date').value;
  var y = document.getElementById('month-date').value;
  document.getElementById('innerp').innerHTML =y + " " + x;
  document.getElementById('report-month').style.backgroundColor= "rgba(254,192,70,0.40)";
  document.getElementById('endtimebtn').style.backgroundColor= "rgba(254,192,70,0.40)";
  document.getElementById('report-time').style.backgroundColor= "white";
  document.getElementById('starttimebtn').style.backgroundColor= "white";
  document.getElementById('sub-for-monthly').style.display="inline-block";
  document.getElementById('sub-for-time').style.display="none";
}
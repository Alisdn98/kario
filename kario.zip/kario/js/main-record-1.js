
function starttime() {
  document.getElementById("starttimebtn").click();
}

function endtime() {
  document.getElementById("endtimebtn").click();
}

function leavetime() {
  document.getElementById("leavetimebtn").click();
}

function startwork() {
  document.getElementById('place-timer-start').placeholder =document.getElementById('first-timer').value;
}

function endwork() {  
  document.getElementById('place-timer-end').placeholder =document.getElementById('timer-2').value;
}

function leavework() { 
  document.getElementById('leavetimework').placeholder =document.getElementById('leave-time').value;
}